package Controller;
import Module.*;
import java.util.*;

public class FruitShopOwner {
    static ArrayList<Fruit> ListFruit = new ArrayList<>();

    public Fruit getFruitById(String id) {
        for (Fruit fruit : ListFruit) {
            if (id.equals(fruit.getFruit_Id())) return fruit;

        }
        return null;
    }

    public  void createFruit()
    {
        while (true)
        {
            String fruitId = Validation.inputString("Enter id:", ".+");
            if (getFruitById(fruitId) != null)
            {
                System.out.println("ID is existed");
                continue;
            }
            String fruitName = Validation.inputString("Select Name:", Validation.NAME);
            double price = Validation.inputDouble("Select  Price:", 1, Double.MAX_VALUE);
            int quantity = Validation.inputInt("Select Quantity:", 1, Integer.MAX_VALUE);
            String origin = Validation.inputString("Select  Origin:", Validation.NAME);
            ListFruit.add(new Fruit(fruitId,fruitName,origin,price,quantity));
            if (!Validation.checkInputYN("Do you want to continue ?")) {
                printListFruit();
                break;
            }

        }
    }
    public void printListFruit(){
        int limit = 1;
        System.out.printf("%-10s%-20s%-20s%-15s\n", "Item", "Fruit name", "Origin", "Price");
        for (Fruit ft: ListFruit) {
            System.out.printf(
                    "%-10d%-20s%-20s%-15.0f$\n",
                    limit,
                    ft.getFruit_Name(),
                    ft.getOrigin(),
                    ft.getPrice());
            limit++;
        }

    }

    public static ArrayList<Fruit> listFruitConditionQuantity(){
        ArrayList<Fruit> newList = new ArrayList<>();
        for (Fruit ft: ListFruit) {
            if (ft.getQuantity() != 0) newList.add(ft);
        }
        return newList;
    }









    public void generateFruit(){
        ListFruit.add(new Fruit("F1", "Chuoi", "Viet nam", 3,100 ));
        ListFruit.add(new Fruit("F2", "Buoi", "Viet nam", 6, 100));
        ListFruit.add(new Fruit("F3", "Dua", "Viet Nam", 5, 100));
    }

}
