package Controller;
import Module.*;
import java.util.*;

public class Product_Order {
    FruitShopOwner fso = new FruitShopOwner();

    Hashtable<String,ArrayList<Fruit>> listHashtable = new Hashtable<>();
    ArrayList<Fruit> listOrder = new ArrayList<>();
    // return index of list Fruit find by quantity
    public  Fruit  displayListFruit() {
        int limit = 0;

        ArrayList<Fruit> fruits = FruitShopOwner.listFruitConditionQuantity();
        System.out.printf("%-10s%-20s%-20s%-15s\n", "Item", "Fruit name", "Origin", "Price");
        for (Fruit fruit : fruits) {
            if (fruit.getQuantity() != 0)
                System.out.printf
                        (
                                "%-10d%-20s%-20s%-15.0f$\n",
                                limit,
                                fruit.getFruit_Name(),
                                fruit.getOrigin(),
                                fruit.getPrice()
                        );    
            limit++;

        }
        int index = Validation.inputInt("Enter item:", 0, limit);

        return fruits.get(index);

    }

    public void order(){

        do {
            Fruit fruit =displayListFruit();
            System.out.println("You selection :" +fruit.getFruit_Name());
            System.out.println("Have "+ fruit.getQuantity() + "in buckets !");
            int quantity = Validation.inputInt(" How much you need  :",0,fruit.getQuantity());
            fruit.setQuantity(fruit.getQuantity()-quantity);
            Fruit checkListOrder = checkListOrder(listOrder,fruit.getFruit_Id());
            if (checkListOrder != null)  checkListOrder.setQuantity(fruit.getQuantity()+quantity);
            else if (quantity != 0) listOrder.add(new Fruit(fruit.getFruit_Id(), fruit.getFruit_Name(),fruit.getOrigin(),fruit.getPrice(),quantity ));


        }while(Validation.checkInputYN("Do you want More! : "));
        if (!listOrder.isEmpty()) {
            //total of list user order
            displayListOrder(listOrder);
            // Add into hashTable
            listHashtable.put(Validation.inputString("Input your name: ", Validation.NAME), listOrder);
        }


    }
    public Fruit checkListOrder(ArrayList<Fruit> listOrder, String id) {
        for (Fruit fruit : listOrder) {
            if (fruit.getFruit_Id().equalsIgnoreCase(id)) return fruit;
        }
        return null;
    }

    public void displayListOrder(ArrayList<Fruit> listOrder) {
        double total = 0;

        System.out.printf("%15s%15s%15s%15s\n", "Product", "Quantity", "Price", "Amount");
        for (Fruit fruit : listOrder) {
            System.out.printf(
                    "%15s%15d%15.0f$%15.0f$\n",
                    fruit.getFruit_Name(),
                    fruit.getQuantity(), fruit.getPrice(),
                    fruit.getPrice() * fruit.getQuantity());
            total += fruit.getPrice() * fruit.getQuantity();
        }
        System.out.println("Total: " + total);
    }
    public void viewOrder() {
        if (listHashtable.isEmpty()) {
            System.out.println("No orders");
            return;
        }
        for (String name : listHashtable.keySet()) {
            System.out.println("Customer: " + name);
            ArrayList<Fruit> listOrder = listHashtable.get(name);
            displayListOrder(listOrder);
        }

    }
}
