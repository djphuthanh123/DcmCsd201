package Controller;

import java.util.Scanner;

public class Validation {
    private final static Scanner sc = new Scanner(System.in);
    protected static final String PHONE_VALID
            = "^(0[3|5|7|8|9])+([0-9]{8})$";

    protected static final String EMAIL_VALID
            = "[A-Za-z]\\w+@\\w+(\\.\\w+)$";
    protected static final String NAME
            = "[A-Za-z0-9\\s]+";

    public static int inputInt(String mess, int min, int max) {
        System.out.print(mess);
        while(true) {
            String input = sc.nextLine();
            try {
                int number = Integer.parseInt(input);
                if (number < min || number > max) {
                    System.out.print("Please input between " + min + ", " + max + ": ");
                    continue;
                }
                return number;
            } catch (Exception e) {
                System.out.print("Please input an integer number ");
            }
        }
    }
    public static Double inputDouble(String mess, double min, double max) {
        System.out.print(mess);
        while(true) {
            String input = sc.nextLine();
            try {
                double number = Double.parseDouble(input);
                if (number < min || number > max) {
                    System.out.print("Please input between " + min + ", " + max + ": ");
                    continue;
                }
                return number;
            } catch (Exception e) {
                System.out.print("Please input an integer number ");
            }
        }
    }



    public static String inputString(String string,String regex) {
        System.out.print(string);
        while(true) {
            String input = sc.nextLine();
            if(!input.matches(regex)){
                System.out.println("Plz input  followed the regex: "+regex);
                continue;
            }
            if (input.equals(" ")) {
                System.out.print("Plz input a non-empty string: ");
                continue;
            }
            return input;
        }
    }

    public static boolean checkInputYN(String string) {
        System.out.println(string);
        while (true) {
            String result = sc.nextLine();
            if (result.equalsIgnoreCase("Y")) {
                return true;
            } else if (result.equalsIgnoreCase("N")) {
                return false;
            }
            System.err.println("Please input y/Y or n/N.");
            System.out.print("Enter again: ");
        }
    }
    public static int inputSelect(String mess, int min, int max) {
        System.out.print(mess);
        while(true) {
            String input = sc.nextLine();
            try {
                int number = Integer.parseInt(input);
                if (number < min || number > max) {
                    System.out.print("Please input between " + min + ", " + max + ": ");
                    continue;
                }
                return number;
            } catch (Exception e) {
                System.out.print("Please input an integer number: ");
            }
        }
    }


}
