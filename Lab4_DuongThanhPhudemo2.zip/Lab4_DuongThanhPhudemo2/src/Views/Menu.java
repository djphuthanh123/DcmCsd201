package Views;

import Controller.Validation;

public class Menu {
    static String menu = """
              FRUIT SHOP SYSTEM             \s
            1. Create Fruit                 \s
            2. View Orders                  \s
            3. Shopping                     \s
            4. Exit                         \s""";

    public static int printMenu() {
        System.out.println(menu);
        return -1 ;
//        Validation.inputInt("Enter your choice : ", 1, 7);
    }


}
