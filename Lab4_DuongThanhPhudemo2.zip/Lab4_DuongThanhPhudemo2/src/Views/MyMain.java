package Views;
import Controller.*;

public class MyMain {
    public static void main(String[] args) {
        // TODO code application logic here
        FruitShopOwner manager = new FruitShopOwner();
        Product_Order po = new Product_Order();
        manager.generateFruit();
        while (true) {
            System.out.println("1. Create Fruit");
            System.out.println("2. View orders");
            System.out.println("3. Shopping (for buyer)");
            System.out.println("4. Exit");
            int choice = Validation.inputInt("Enter choice:", 1, 4);
            switch (choice) {
                case 1:
                    manager.createFruit();
                    break;
                case 2:
                    po.viewOrder();
                    break;
                case 3:
                    po.order();
                    break;
                case 4:
                    return;
            }
        }
    }

}
