package Module;

public class Fruit {
    private String  Fruit_Id,Origin,Fruit_Name;
    private double price;
    private int Quantity;

    public Fruit(String fruit_Id, String fruit_Name, String origin, double price, int quantity) {
        this.Fruit_Id = fruit_Id;
        this.Origin = origin;
       this. Fruit_Name = fruit_Name;
        this.price = price;
        this.Quantity = quantity;
    }

    public String getFruit_Id() {
        return Fruit_Id;
    }

    public void setFruit_Id(String fruit_Id) {
        Fruit_Id = fruit_Id;
    }

    public String getOrigin() {
        return Origin;
    }

    public void setOrigin(String origin) {
        Origin = origin;
    }

    public String getFruit_Name() {
        return Fruit_Name;
    }

    public void setFruit_Name(String fruit_Name) {
        Fruit_Name = fruit_Name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }


}
